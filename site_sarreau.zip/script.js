
const btn=document.getElementById('toggle');const mobile=document.getElementById('mobile');
if(btn){btn.addEventListener('click',()=>mobile.classList.toggle('show'));}
